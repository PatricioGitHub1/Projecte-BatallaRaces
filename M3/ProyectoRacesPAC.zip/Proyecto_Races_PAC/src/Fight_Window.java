

import java.awt.BasicStroke;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.geom.AffineTransform;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.awt.BorderLayout;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.*;

import javax.imageio.ImageIO;
import javax.swing.*;

public class Fight_Window extends JFrame {
	private static Fight_Window instance;
	private PlayersImage playimage;
	private JPanel panel0, panel1, panel2, panel3;
	private JButton chooseCharacter, chooseWeapon,ranking,fight,clear;
	private String urlDatos = "jdbc:mysql://localhost/RacesPAC?serverTimezone=UTC";
	private String usuario = "root";
	private String pass = "1234";
	private JTextArea console;
	private Fight f;
	private BBDD bd;
	
	public Fight_Window(String userimg, String userweapon, String botimg, String botweapon,int id,String username,Warrior warrior_enemy, Weapons weapons_enemy,Warrior user_warrior,Weapons user_weapon) {
		instance = this;
		panel0 = new JPanel();
        panel1 = new JPanel();
        panel2 = new JPanel();
        panel3 = new JPanel();
        clear = new JButton("Clear Console");
        bd = new BBDD();
        
        console = new JTextArea();
        console.setEditable(false);
        
        JScrollPane scrollPane = new JScrollPane(console);
        clear.addActionListener(new ActionListener() {

                    @Override
                    public void actionPerformed(ActionEvent e) {
                        clearConsole();

                    }
                });

        playimage = new PlayersImage(userimg,userweapon,botimg,botweapon);
        chooseCharacter = new JButton("Choose Character");
        chooseWeapon = new JButton("Choose Weapon");
        ranking = new JButton("Ranking");
        fight = new JButton("Fight");
        
        //Estos if son para el tamaño de la barra de la vida
        if(user_warrior instanceof Elf) {
			playimage.userMaximum(40);
		}else if (user_warrior instanceof Human) {
			playimage.userMaximum(50);
		}else if (user_warrior instanceof Dwarf){
			playimage.userMaximum(60);
		}
		if(warrior_enemy instanceof Elf) {
			playimage.botMaximum(40);
		}else if (warrior_enemy instanceof Human) {
			playimage.botMaximum(50);
		}else if (warrior_enemy instanceof Dwarf){
			playimage.botMaximum(60);
		}
        
        
        
        panel1.add(chooseCharacter);
        panel1.add(chooseWeapon);
        panel1.add(ranking);
        panel2.add(playimage);
        panel2.add(fight);
        panel2.add(clear);
        
        scrollPane.setPreferredSize(new Dimension(200, 80));
        panel1.setOpaque(false);
        panel2.setOpaque(false);
        panel3.setOpaque(false);
        
        panel0.add(panel1);
        panel0.add(panel2);
        panel0.add(panel3);
        panel0.add(scrollPane);
		f=new Fight();
		
		
		

        ranking.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				//Creamos instancia de la clase ranking
				new Ranking();
				
			}
		});
        
        chooseCharacter.addActionListener(new ActionListener() {
        	
			@Override
			public void actionPerformed(ActionEvent e) {
				//Resetea el arraylist de rondas y pone las rondas a cero
				if (f.getRounds()>=1) {
					f.setTotal_points(0);
					f.getRoundsarray().clear();
					
					user_warrior.resetStats();
					warrior_enemy.resetStats();
					bd.updatePlayer(username, 0);
				}
				
				dispose();
				new FrameWarriors(username);
				
			}
		});
        
        chooseWeapon.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				if (userimg!="./imagenes/-.jpg") {
					clearConsole();
					dispose();
					new FrameWeapons(id,userimg,username,botimg,botweapon,warrior_enemy,weapons_enemy,user_warrior);
					user_warrior.resetStats();
					warrior_enemy.resetStats();
					f.getRoundsarray().clear();
					
				}else {
					consoleText("First you have to choose a Warrior");
				}
				
				
			}
		});
        
        fight.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				//If para comprobar que no se puede pulsar el boton fight sin escoger arma y guerrero.
				if (userimg!="./imagenes/-.jpg" && userweapon!="./imagenes/-.jpg") {
					if (warrior_enemy.getHealth()<=0 || user_warrior.getHealth()<=0) {
						String winner_name = "";
						f.setRounds(0);
						
						//Vida enemigo o aliado menor o igual que 0, insertamos las rondas y la batalla a la base de datos
						if (warrior_enemy.getHealth()<=0) {
							winner_name = username+" has won the Battle!\n";
							f.setTotal_points(warrior_enemy.getPoints_value()+weapons_enemy.getPoints_value());
							bd.insertBattle(bd.playerId(),user_warrior.getId(),user_weapon.getId(),warrior_enemy.getId(),weapons_enemy.getId(), warrior_enemy.getInitial_health()-warrior_enemy.getHealth(), user_warrior.getInitial_health()-user_warrior.getHealth(),f.getTotal_points());
							bd.addRounds(f.getRoundsarray());
							f.getRoundsarray().clear();
						}else if(user_warrior.getHealth()<=0) {
							winner_name = "The Bot has won the Battle!\n";
							bd.insertBattle(bd.playerId(),user_warrior.getId(),user_weapon.getId(),warrior_enemy.getId(),weapons_enemy.getId(), warrior_enemy.getInitial_health()-warrior_enemy.getHealth(), user_warrior.getInitial_health()-user_warrior.getHealth(),0);
							bd.addRounds(f.getRoundsarray());
							f.getRoundsarray().clear();
						}
						//Creamos instancia para la ventana JOptionPane, cuando terminas una batalla, donde te pide si quieres continuar luchando.
						new EndFightWindow(user_warrior,warrior_enemy,username,f.getTotal_points(),user_weapon, winner_name);
					}else {
						//Llamamos al metodo de la lucha, para realizar el combate
						f.singleFight(username, warrior_enemy, weapons_enemy, user_warrior, user_weapon);
						//Llamamos a los metodos para cambiar la salud de las barras y los atributos de cada personaje.
						playimage.userProgBar(user_warrior.getHealth());
						playimage.botProgBar(warrior_enemy.getHealth());
						playimage.userAgilitiBar(user_warrior.getAgility()*10);
						playimage.userDefBar(user_warrior.getDefense()*10);
						playimage.userPowerBar(user_warrior.getStrength()+user_weapon.getStrength()*10);
						playimage.userSpeedBar(user_warrior.getSpeed()+user_weapon.getSpeed()*10);
						playimage.botAgilitiBar(warrior_enemy.getAgility()*10);
						playimage.botDefBar(warrior_enemy.getDefense()*10);
						playimage.botPowerBar(warrior_enemy.getStrength()+weapons_enemy.getStrength()*10);
						playimage.botSpeedBar(warrior_enemy.getSpeed()+weapons_enemy.getSpeed()*10);

					}
				}
				
			}
		});
        
        this.add(panel0);
        panel0.setLayout(new BoxLayout(panel0, BoxLayout.Y_AXIS));
        
        setSize(1250, 800);
        setResizable(true);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setVisible(true);
	}
	
	public void clearConsole() {
        console.setText("");
    }
	public void consoleText(String text) {
        console.append(text+"\n");
    }
	
	public static Fight_Window getInstance() {
	    return instance;
	}
	
	
	
	
	
	
}

class PlayersImage extends JPanel{
	private JPanel panel2,panel3;
	
	private BufferedImage userImage;
	private BufferedImage botImage,versus;
	private int characterimageWidth = 501;
    private int charaterimageHeight = 370;
    private JLabel usupower,usuagility,ususpeed,usudefense,botpower,botagility,botspeed,botdefense;
    
	private BufferedImage userweaponImage;
	private BufferedImage botweaponImage;
	private int weaponimageWidth = 140;
    private int weaponimageHeight = 98;
    
    private JProgressBar barbot,baruser,barusupower,barusuagility,barususpeed,barusudefense,barbotpower,barbotagility,barbotspeed,barbotdefense;
	private String userimg1,userweapon1,botimg1,botweapon1;
	
	
    
    public PlayersImage(String userimg, String userweapon, String botimg, String botweapon) {
    	userimg1 = userimg;
    	userweapon1 = userweapon;
    	botimg1 = botimg;
    	botweapon1 = botweapon;
		setPreferredSize(new Dimension(1250,525));
		setOpaque(false);
		
		panel2 = new JPanel();
		panel3 = new JPanel();
		panel2.setLayout(new BoxLayout(panel2, BoxLayout.Y_AXIS));
		panel3.setLayout(new BoxLayout(panel3, BoxLayout.Y_AXIS));
		
		usupower = new JLabel("Power");
		usuagility = new JLabel("Agility");
		ususpeed = new JLabel("Speed");
		usudefense = new JLabel("Defense");
		
		usupower.setFont(new Font("Arial", Font.BOLD, 20));
		usuagility.setFont(new Font("Arial", Font.BOLD, 20));
		ususpeed.setFont(new Font("Arial", Font.BOLD, 20));
		usudefense.setFont(new Font("Arial", Font.BOLD, 20));
		
		botpower = new JLabel("Power");
		botagility = new JLabel("Agility");
		botspeed = new JLabel("Speed");
		botdefense = new JLabel("Defense");
		
		botpower.setFont(new Font("Arial", Font.BOLD, 20));
		botagility.setFont(new Font("Arial", Font.BOLD, 20));
		botspeed.setFont(new Font("Arial", Font.BOLD, 20));
		botdefense.setFont(new Font("Arial", Font.BOLD, 20));
		Font font = new Font("Arial", Font.BOLD, 15);
		
		// BARRA PROGRESION ARMA
		barusupower = new JProgressBar();
		barusuagility = new JProgressBar();
		barususpeed = new JProgressBar();
		barusudefense = new JProgressBar();
		
		barbotpower = new JProgressBar();
		barbotagility = new JProgressBar();
		barbotspeed = new JProgressBar();
		barbotdefense = new JProgressBar();
		
		barusupower.setMinimum(0);
		barusupower.setMaximum(100);
		barusupower.setValue(0);
		barusupower.setForeground(Color.red);
		barusupower.setBackground(Color.white);

		barusuagility.setMinimum(0);
		barusuagility.setMaximum(100);
		barusuagility.setValue(0);
		barusuagility.setForeground(Color.green);
		barusuagility.setBackground(Color.white);

		barususpeed.setMinimum(0);
		barususpeed.setMaximum(100);
		barususpeed.setValue(0);
		barususpeed.setForeground(Color.blue);
		barususpeed.setBackground(Color.white);

		barusudefense.setMinimum(0);
		barusudefense.setMaximum(100);
		barusudefense.setValue(0);
		barusudefense.setForeground(Color.darkGray);
		barusudefense.setBackground(Color.white);
		//----------------------------------------------------------------------
		barbotpower.setMinimum(0);
		barbotpower.setMaximum(100);
		barbotpower.setValue(0);
		barbotpower.setForeground(Color.red);
		barbotpower.setBackground(Color.white);
		
		barbotagility.setMinimum(0);
		barbotagility.setMaximum(100);
		barbotagility.setValue(0);
		barbotagility.setForeground(Color.green);
		barbotagility.setBackground(Color.white);

		barbotspeed.setMinimum(0);
		barbotspeed.setMaximum(100);
		barbotspeed.setValue(0);
		barbotspeed.setForeground(Color.blue);
		barbotspeed.setBackground(Color.white);

		barbotdefense.setMinimum(0);
		barbotdefense.setMaximum(100);
		barbotdefense.setValue(0);
		barbotdefense.setForeground(Color.darkGray);
		barbotdefense.setBackground(Color.white);

		panel2.add(usupower);
		panel2.add(usuagility);
		panel2.add(ususpeed);
		panel2.add(usudefense);
		
		panel3.add(botpower);
		panel3.add(botagility);
		panel3.add(botspeed);
		panel3.add(botdefense);
		
		this.add(barusupower);
		this.add(barusuagility);
		this.add(barususpeed);
		this.add(barusudefense);
		
		this.add(barbotpower);
		this.add(barbotagility);
		this.add(barbotspeed);
		this.add(barbotdefense);


		barusupower.setBounds(300, 431, 201, 22); 
		barusuagility.setBounds(300, 453, 201, 22);
		barususpeed.setBounds(300, 474, 201, 22);
		barusudefense.setBounds(300, 496, 201, 22);
		
		barbotpower.setBounds(1049, 431, 201, 22); 
		barbotagility.setBounds(1049, 453, 201, 22);
		barbotspeed.setBounds(1049, 474, 201, 22);
		barbotdefense.setBounds(1049, 496, 201, 22);
		

		
		// BARRA PROGRESION USUARIOS
		barbot = new JProgressBar();
		barbot.setMinimum(0);
		barbot.setMaximum(0);
		barbot.setStringPainted(true);
		barbot.setValue(0);
		barbot.setForeground(Color.green);
		barbot.setBackground(Color.RED);
		barbot.setFont(font);
		
		baruser = new JProgressBar();
		baruser.setMinimum(0);
		baruser.setMaximum(0);
		baruser.setStringPainted(true);
		baruser.setValue(0);
		baruser.setStringPainted(true);
		baruser.setValue(0);
		baruser.setForeground(Color.green);
		baruser.setBackground(Color.RED);
		baruser.setFont(font);
		
		this.add(barbot);
		this.add(baruser);
		baruser.setBounds(0, 1, 501, 60);
		barbot.setBounds(750, 1, 500, 60);
		this.setLayout(null);
		panel2.setBounds(150, 431, 100, 95);
		panel3.setBounds(900, 431, 100, 95);
		this.add(panel2);
		this.add(panel3);
		
		
	}
    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
		// Link de la foto character
		String linkcharacteruser = userimg1;
		String linkcharacterbot = botimg1;
		// Link de la foto weapon
		String linkweaponuser = userweapon1;
		String linkweaponbot = botweapon1;
		try {
        	//foto usuario
        	versus = ImageIO.read(new File("./imagenes/versus.jpg"));
            g.drawImage(versus.getScaledInstance(characterimageWidth, charaterimageHeight, Image.SCALE_SMOOTH), 385, 61, null);

        } catch (IOException e) {
            e.printStackTrace();
        }
		// IMAGENES CHARACTERS
        try {
        	//foto usuario
        	userImage = ImageIO.read(new File(linkcharacteruser));
            g.drawImage(userImage.getScaledInstance(characterimageWidth, charaterimageHeight, Image.SCALE_SMOOTH), 0, 61, null);

        } catch (IOException e) {
            e.printStackTrace();
        }
        try {
        	//foto bot
            botImage = ImageIO.read(new File(linkcharacterbot));
            g.drawImage(botImage.getScaledInstance(characterimageWidth, charaterimageHeight, Image.SCALE_SMOOTH), 750, 61, null);
        } catch (IOException e) {
            e.printStackTrace();
        }
        
        //IMAGENES WEAPONS
        try {
        	//foto usuario
        	userweaponImage = ImageIO.read(new File(linkweaponuser));
            g.drawImage(userweaponImage.getScaledInstance(weaponimageWidth, weaponimageHeight, Image.SCALE_SMOOTH), 0, 431, null);

        } catch (IOException e) {
            e.printStackTrace();
        }
        try {
        	//foto bot
        	botweaponImage = ImageIO.read(new File(linkweaponbot));
            g.drawImage(botweaponImage.getScaledInstance(weaponimageWidth, weaponimageHeight, Image.SCALE_SMOOTH), 750, 431, null);
        } catch (IOException e) {
            e.printStackTrace();
        }
        
    }
    
    /*---------------------------------------------------*/
    public void userProgBar(Integer total) {
        baruser.setValue(total);
    }
    public void botProgBar(Integer total) {
        barbot.setValue(total);
    }
    public void userMaximum(Integer total) {
    	baruser.setMaximum(total);
    }
    public void botMaximum(Integer total) {
    	barbot.setMaximum(total);
    }
    /*----------------------------------------------------*/
    public void userPowerBar(Integer total) {
    	barusupower.setValue(total);
    }
    public void userSpeedBar(Integer total) {
    	barusuagility.setValue(total);
    }
    public void userAgilitiBar(Integer total) {
    	barususpeed.setValue(total);
    }
    public void userDefBar(Integer total) {
    	barusudefense.setValue(total);
    }
    /*----------------------------------------------------*/
    public void botPowerBar(Integer total) {
    	barbotpower.setValue(total);
    }
    public void botSpeedBar(Integer total) {
    	barbotagility.setValue(total);
    }
    public void botAgilitiBar(Integer total) {
    	barbotspeed.setValue(total);
    }
    public void botDefBar(Integer total) {
    	barbotdefense.setValue(total);
    }
    
}
