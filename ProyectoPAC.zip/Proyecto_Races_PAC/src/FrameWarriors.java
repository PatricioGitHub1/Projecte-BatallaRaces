import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class FrameWarriors extends JFrame{

	private JPanel p0,p1,p2,p3;
	private ArrayList<JLabel> arraylabels;
	private String userwarriorpath,botwarriorpath,botweaponpath;
	private Warrior userwarrior;
	
	
	
	
	FrameWarriors(String username){
		arraylabels = new ArrayList<JLabel>();
		WarriorContainer w1 = new WarriorContainer();
		w1.addWArrior();
		//For para crear labels con cada imagen de los guerreros.
		for (int i=0;i<w1.getWarriorarray().size();i++) {
			ImageIcon icono = new ImageIcon(w1.getWarriorarray().get(i).getImage_path());
			Image imagenOriginal = icono.getImage();
	        Image imagenRedimensionada = imagenOriginal.getScaledInstance(200, 150, Image.SCALE_SMOOTH);
	        ImageIcon iconoRedimensionado = new ImageIcon(imagenRedimensionada);
	        JLabel label = new JLabel(iconoRedimensionado);
	        arraylabels.add(label);
		}
		//For para crear Mouse Listener en cada imagen, sirve para que cuando cliquemos en una imagen elija a ese personaje
		for (int i = 0; i<arraylabels.size();i++) {
			JLabel label = arraylabels.get(i);
			arraylabels.get(i).addMouseListener(new MouseAdapter() {
			
				public void mouseClicked(MouseEvent e) {
					int index = arraylabels.indexOf(label);

					dispose();
					//Creamos instancia del enemigo, que se elige aleatoriamente y se lo pasamos al constructor de Fight_Window.
					WarriorEnemy we = new WarriorEnemy();
					we.Enemy_Random();
					Warrior warrior_enemy = we.getWarrior_enemy();
					Weapons weapon_enemy = we.getWeapon();
					userwarriorpath=w1.getWarriorarray().get(index).getImage_path();
					botwarriorpath = we.getWarrior_enemy().getImage_path();
					botweaponpath = we.getWeapon().getWeapon_image_path();
					userwarrior = w1.getWarriorarray().get(index);
					//Id que sirve para saber que persoanje que es para despues escoger las armas oportunas.
					int id_warrior = w1.getWarriorarray().get(index).getId();
					
					new Fight_Window(userwarriorpath,"./imagenes/-.jpg",botwarriorpath ,botweaponpath,id_warrior,username,warrior_enemy,weapon_enemy,userwarrior,null);
					
					
				}
				
			});
		}
		
		p0 = new JPanel();
		p1 = new JPanel();
		p2 = new JPanel();
		p3 = new JPanel();
		for (int i = 0;i<4;i++) {
			p1.add(arraylabels.get(i));
		}
		for (int i = 4;i<8;i++) {
			p2.add(arraylabels.get(i));
		}
		for (int i = 8;i<12;i++) {
			p3.add(arraylabels.get(i));
		}
		
		p0.add(p1);
		p0.add(p2);
		p0.add(p3);
		add(p0);
		setSize(850,550);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setLocationRelativeTo(null);
		setVisible(true);
			
		}
	public static void main(String[] args) {

	}

}
