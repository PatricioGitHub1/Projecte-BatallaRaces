import java.util.ArrayList;

import javax.swing.JOptionPane;

public class Fight{
	private int enemy_health;
	private int player_health;
	private int total_points=0;
	private boolean turn;
	private int rounds;
	private ArrayList<Rounds> roundsarray;
	private int totalDamage;
	private BBDD bd;
	
	public ArrayList<Rounds> getRoundsarray() {
		return roundsarray;
	}

	public int getTotalDamage() {
		return totalDamage;
	}

	public int getRounds() {
		return rounds;
	}

	public void setRounds(int rounds) {
		this.rounds = rounds;
	}

	
	
	public Fight() {
		roundsarray = new ArrayList<Rounds>();
		bd = new BBDD();
		
	}
	public void singleFight (String username,Warrior warrior_enemy, Weapons weapons_enemy,Warrior user_warrior,Weapons user_weapon) {
		Fight_Window vn = Fight_Window.getInstance();
		rounds++;
		if (rounds == 1) {
			turn = getFasterWarrior(user_warrior, warrior_enemy, user_weapon, weapons_enemy);
		}
		
		//FALSO = BOT, VERDADERO = HUMANO
		int percentageAtkHits = 1 + (int) (Math.random() * 101);
		vn.consoleText("=============================================================================");
		if (turn) {
			vn.consoleText("Round number "+rounds+" | Turn of "+username);
			turn = roundFight(user_warrior, warrior_enemy,user_weapon,weapons_enemy,turn);
			roundsarray.add(new Rounds(rounds,0,user_warrior.getId(),user_weapon.getId(),warrior_enemy.getId(),weapons_enemy.getId(),getTotalDamage(),0));
		} else if (!turn) {
			vn.consoleText("Round number "+rounds+" | Turn of Bot");	
			turn = roundFight(warrior_enemy, user_warrior,weapons_enemy,user_weapon,turn);
			roundsarray.add(new Rounds(rounds,0,user_warrior.getId(),user_weapon.getId(),warrior_enemy.getId(),weapons_enemy.getId(),0,getTotalDamage()));
		}
		
		
		
		
	}
	
	
	
	
	boolean roundFight(Warrior attacker, Warrior defender,Weapons weapon_attacker,Weapons weapon_defender,boolean turno) {
		Fight_Window vn = Fight_Window.getInstance();
		vn.consoleText("=============================================================================");
		int percentageAtkHits = 1 + (int) (Math.random() * 101);
		if ((attacker.getAgility()) * 10 > percentageAtkHits) {
			vn.consoleText("The attack was succesful");
			int percentageDodge = 1 + (int) (Math.random() * 51);
			
			if ((defender.getAgility()) > percentageDodge) {
				vn.consoleText(defender.getName()+" has dodged the attack");
				vn.consoleText("Role swap");
				return changeTurn(turno);
			} else {
				//EN ESTE CASO EL ATAQUE HA TENIDO EXITO Y EL DEFENSOR NO HA PODIDO DEFENDERSE
				totalDamage = attacker.getStrength() + weapon_attacker.getStrength() - defender.getDefense();
				int updatedDefHealth = defender.getHealth() - totalDamage;
				defender.setHealth(updatedDefHealth);
				vn.consoleText(defender.getName() + " has received "+totalDamage+ " damage points from "+attacker.getName());
				//AQUI MODIFICAR LA BARRITA DE SALUD DEL DEFENSOR
				//
				///
				
				//Ver si atacante puede repetir turnp
				if (attacker.getSpeed() + weapon_attacker.getSpeed() <= defender.getSpeed()+weapon_defender.getSpeed()) {
					vn.consoleText("Role swap");
					return changeTurn(turno);
					
				}
				
				//En el caso que la velocidad del defensor no sea mayor al atacante
				int changeToSwap = 1 + (int) (Math.random() * 101);
				if ((attacker.getSpeed() + weapon_attacker.getSpeed() - defender.getSpeed() - weapon_defender.getSpeed())*10 > changeToSwap) {
					vn.consoleText("The attacker keeps the offensive");
					return turno;
				}
				vn.consoleText("Role swap");
				return changeTurn(turno);
				}
			
		} else {
			vn.consoleText("The attack failed");
			vn.consoleText("Role swap");	
			return changeTurn(turno);
		}
	}
	
	 boolean changeTurn(boolean current) {
			if (current) {
				return false;
			} else {
				return true;
			}
	}
	 
	 boolean getFasterWarrior(Warrior user,Warrior bot,Weapons user1, Weapons bot1) {
			//True es humano y False es el bot
			if (user.getSpeed()+user1.getSpeed() == bot.getSpeed()+bot1.getSpeed()) {
				if (user.getAgility() == bot.getAgility()) {
					int random_index = (int) Math.random()*2;
					if (random_index == 0) {
						return false;
					} else {
						return true;
					}
				} else if (user.getAgility() > bot.getAgility()) {
					return true;
				} else {
					return false;
				}
			} else if (user.getSpeed()+user1.getSpeed() > bot.getSpeed()+bot1.getSpeed()) {
				return true;
			} else {
				return false;
			}
	}
	
	
	public int getEnemy_health() {
		return enemy_health;
	}


	public void setEnemy_health(int enemy_health) {
		this.enemy_health = enemy_health;
	}


	public int getPlayer_health() {
		return player_health;
	}


	public void setPlayer_health(int player_health) {
		this.player_health = player_health;
	}


	public int getTotal_points() {
		return total_points;
	}


	public void setTotal_points(int total_points) {
		this.total_points = total_points;
	}


	public static void main(String[] args) {

	}

}

class EndFightWindow {

    public EndFightWindow(Warrior user,Warrior bot,String username,int total_points,Weapons weapon, String winner_name) {
        String message = winner_name+"Do you want to keep fighting?";
        int answer;
        answer = JOptionPane.showOptionDialog(null, message, "End Of Battle", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE, null, null, null);
        actionJOption(answer, user,bot,username,total_points,weapon);
    }
    
    public void actionJOption(int single_case, Warrior user, Warrior bot,String username,int total_points,Weapons weapon) {
    	Fight_Window vn = Fight_Window.getInstance();
    	BBDD bd = new BBDD();
        if (single_case == JOptionPane.YES_OPTION) {
            //CASE ANSWER IS YES, AND CHECK IF USER IS ALIVE
            if (user.getHealth() <= 0) {
                //VIDA MENOR QUE 0
                bd.updatePlayer(username, 0);
                user.resetStats();
                bot.resetStats();
                String imagen="./imagenes/-.jpg";
                vn.dispose();
                new Fight_Window(imagen,imagen,imagen,imagen,0,username,null,null,null,null);
            } else {
                //VIDA MAYOR QUE 0
                user.resetStats();
                bot.resetStats();
                bd.updatePlayer(username, total_points);
                WarriorEnemy we = new WarriorEnemy();
                we.Enemy_Random();
                vn.dispose();
                new Fight_Window(user.getImage_path(),weapon.getWeapon_image_path() , we.getWarrior_enemy().getImage_path(), we.getWeapon().getWeapon_image_path(), user.getId(), username, we.getWarrior_enemy(), we.getWeapon(), user, weapon);
            }
        } else {
            //CASE ANSWER IS NO,//
        	vn.dispose();
        	bd.updatePlayer(username, total_points);
                
         }
                
        }
    }

